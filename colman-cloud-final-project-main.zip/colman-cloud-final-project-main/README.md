# Final Project from [Colman Computer Science hosted on AWS](https://www.colman.ac.il/) 🎓
## 🚀 Getting Started
### Project overview 
- We will use the folowing aws resource :
- VPC include subnets,routetable ,internetgateway , securitygroup
- RDS hosted mysql and custom subnet group
- EC2 and ec2 target grouop
- Application load balancer
- The application work as describe in the following diagram
  
### To run this project on your system:
-   Ensure that `git` and `npm` and `maven` are installed on your system
```
echo "Installing Git and nodejs"
sudo yum update -y
sudo yum install git -y
sudo yum install npm -y 
sudo yum install maven -y
```
-   Now Clone the project code
-   In your terminal,run the following commands
-   Clone website code
```
echo "Cloning website"
sudo mkdir -p /demo-website
cd /demo-website
sudo git clone https://github.com/omer5574/colman-cloud-final-project.git .

```
-   Install the dependencies
```
# Install dependencies
echo "Installing dependencies"
sudo npm install
#Install dotenv for read env variables from .env file
sudo npm install dotenv
```
-   You'll need to create .env file on the application directory with env variables for DB connection
-   For example of .env file
```
DB_HOST="Enter RDS endpoint here"
DB_USER="Enter RDS username here"
DB_PASSWORD="Enter RDS password here"
DB_NAME="Enter RDS database name here"
```
-  Install & use pm2 to run Node app in background
-  To start the web server, execute (without debugging):
```
echo "Installing & starting pm2"
sudo npm install pm2@latest -g
pm2 start app.js
```
-   To ensure that your Node.js app starts automatically after a system restart, you can use PM2's startup script generation      feature.
-   PM2 provides an easy way to generate and configure startup scripts for your Node.js applications, allowing them to be         automatically started on system boot.
-   Follow these steps to generate a startup script for your Node.js app with PM2:
-   Ensure that your Node.js app is running with PM2. If it's not running, start it using the following command:
```
pm2 start app.js
```
- Generate the startup script:
```
pm2 startup
```
- PM2 will display a command that you need to run with administrative privileges (using sudo) to set up the startup script.
- Copy the command from the output of the previous step and run it with sudo:
- For example, the command might look something like:
```
sudo env PATH=$PATH:/usr/bin /usr/local/lib/node_modules/pm2/bin/pm2 startup systemd -u ec2-user --hp /home/ec2-user
```
## 📣 Attention
- Please see deploy_scirpt.sh script for those step 
